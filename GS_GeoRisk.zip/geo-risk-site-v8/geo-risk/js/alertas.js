/* Simulador de alertas — preview em tempo real + validação */
(function () {
  const form = document.getElementById("formAlerta");
  if (!form) return;

  const previa = {
    regiao: document.getElementById("previaRegiao"),
    tipo: document.getElementById("previaTipo"),
    severidade: document.getElementById("previaSeveridade"),
    mensagem: document.getElementById("previaMensagem"),
    tag: document.getElementById("previaTag"),
  };

  function atualizarPrevia() {
    previa.regiao.textContent = form.regiao.value || "—";
    const tipo = form.tipo.options[form.tipo.selectedIndex];
    previa.tipo.textContent = tipo && tipo.value ? tipo.textContent : "—";
    const sev = form.severidade.value || "baixa";
    previa.severidade.textContent = sev.toUpperCase();
    previa.mensagem.textContent = form.mensagem.value || "Mensagem do alerta aparecerá aqui.";
    previa.tag.textContent = sev.toUpperCase();
    previa.tag.className = "alertaTag " + (sev === "critica" ? "critico" : sev === "alta" ? "aviso" : "");
    // remapeia para classes do alertaItem
    if (sev === "critica") previa.tag.classList.add("alertaTag");
  }

  ["regiao", "tipo", "severidade", "mensagem"].forEach(function (n) {
    form[n].addEventListener("input", atualizarPrevia);
    form[n].addEventListener("change", atualizarPrevia);
  });
  atualizarPrevia();

  function validar() {
    let ok = true;
    function set(name, msg) {
      const el = form.querySelector('[data-erro="' + name + '"]');
      if (el) el.textContent = msg;
      if (msg) ok = false;
    }
    set("regiao", form.regiao.value.trim().length < 2 ? "Informe a região afetada." : "");
    set("tipo", !form.tipo.value ? "Selecione o tipo de desastre." : "");
    set("severidade", !form.severidade.value ? "Selecione a severidade." : "");
    const m = form.mensagem.value.trim();
    set("mensagem", m.length < 10 ? "Mensagem curta demais (mín. 10)." : (m.length > 280 ? "Máx. 280 caracteres." : ""));
    return ok;
  }

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    if (!validar()) return;
    const sucesso = document.getElementById("feedbackEnvio");
    if (sucesso) {
      sucesso.classList.add("estaVisivel");
      setTimeout(function () { sucesso.classList.remove("estaVisivel"); }, 4000);
    }
    form.reset();
    atualizarPrevia();
  });
})();
