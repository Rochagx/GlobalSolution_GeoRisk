/* Menu, FAQ, tabs, modal — Órbita Sentinel */

// ---------- MENU MOBILE ----------
const navToggle = document.querySelector(".navegacaoBotao");
const navLinks = document.querySelector(".navegacaoLinks");

if (navToggle && navLinks) {
  navToggle.addEventListener("click", function () {
    const aberto = navLinks.classList.toggle("estaAberto");
    navToggle.classList.toggle("estaAberto");
    navToggle.setAttribute("aria-expanded", aberto ? "true" : "false");
  });

  const linksMenu = navLinks.querySelectorAll("a");
  for (let i = 0; i < linksMenu.length; i++) {
    linksMenu[i].addEventListener("click", function () {
      navLinks.classList.remove("estaAberto");
      navToggle.classList.remove("estaAberto");
      navToggle.setAttribute("aria-expanded", "false");
    });
  }
}

// Marca o link da página atual
let paginaAtual = window.location.pathname.split("/").pop();
if (paginaAtual === "") paginaAtual = "index.html";
const todosLinks = document.querySelectorAll(".navegacaoLinks a");
for (let i = 0; i < todosLinks.length; i++) {
  if (todosLinks[i].getAttribute("href") === paginaAtual) {
    todosLinks[i].classList.add("ativo");
  }
}

// ---------- FAQ ACORDEON ----------
const perguntas = document.querySelectorAll(".faqPergunta");
for (let i = 0; i < perguntas.length; i++) {
  perguntas[i].addEventListener("click", function () {
    const item = perguntas[i].parentElement;
    const estavaAberto = item.classList.contains("estaAberto");
    const todosItens = document.querySelectorAll(".faqItem");
    for (let j = 0; j < todosItens.length; j++) todosItens[j].classList.remove("estaAberto");
    if (!estavaAberto) item.classList.add("estaAberto");
  });
}

// ---------- TABS ----------
const todasTabs = document.querySelectorAll(".abas");
for (let i = 0; i < todasTabs.length; i++) {
  const tabsEl = todasTabs[i];
  const botoes = tabsEl.querySelectorAll(".abaBotao");
  for (let j = 0; j < botoes.length; j++) {
    botoes[j].addEventListener("click", function () {
      const alvo = botoes[j].dataset.tab;
      const container = tabsEl.parentElement;
      const botoesC = container.querySelectorAll(".abaBotao");
      for (let k = 0; k < botoesC.length; k++) botoesC[k].classList.remove("estaAtivo");
      const paineis = container.querySelectorAll(".abaPainel");
      for (let k = 0; k < paineis.length; k++) paineis[k].classList.remove("estaAtivo");
      botoes[j].classList.add("estaAtivo");
      const painel = container.querySelector('.abaPainel[data-tab="' + alvo + '"]');
      if (painel) painel.classList.add("estaAtivo");
    });
  }
}

// ---------- MODAL ----------
const botoesAbrirModal = document.querySelectorAll("[data-modal-open]");
for (let i = 0; i < botoesAbrirModal.length; i++) {
  botoesAbrirModal[i].addEventListener("click", function () {
    const id = botoesAbrirModal[i].dataset.modalOpen;
    const modal = document.getElementById(id);
    if (modal) modal.classList.add("estaAberto");
  });
}
const fundosModal = document.querySelectorAll(".modalFundo");
for (let i = 0; i < fundosModal.length; i++) {
  fundosModal[i].addEventListener("click", function (e) {
    if (e.target === fundosModal[i] || e.target.classList.contains("modalFechar")) {
      fundosModal[i].classList.remove("estaAberto");
    }
  });
}
document.addEventListener("keydown", function (e) {
  if (e.key === "Escape") {
    const abertos = document.querySelectorAll(".modalFundo.estaAberto");
    for (let i = 0; i < abertos.length; i++) abertos[i].classList.remove("estaAberto");
  }
});

// ---------- ANIMAÇÃO DE ENTRADA ----------
window.addEventListener("load", function () {
  const elementos = document.querySelectorAll("[data-animate]");
  for (let i = 0; i < elementos.length; i++) elementos[i].classList.add("aparecerCima");
});

// ---------- ANO DINÂMICO ----------
const ano = document.getElementById("current-year");
if (ano) ano.textContent = new Date().getFullYear();
