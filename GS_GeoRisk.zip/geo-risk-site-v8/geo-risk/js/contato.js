/* Validação do formulário de contato */
(function () {
  const form = document.getElementById("formContato");
  if (!form) return;

  const campos = {
    nome: { el: form.nome, erro: form.querySelector('[data-erro="nome"]'), validar: function (v) {
      v = v.trim();
      if (v.length < 3) return "Informe um nome com pelo menos 3 caracteres.";
      if (v.length > 80) return "Máximo de 80 caracteres.";
      return "";
    }},
    email: { el: form.email, erro: form.querySelector('[data-erro="email"]'), validar: function (v) {
      v = v.trim();
      if (!v) return "Informe seu e-mail.";
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) return "E-mail inválido.";
      return "";
    }},
    assunto: { el: form.assunto, erro: form.querySelector('[data-erro="assunto"]'), validar: function (v) {
      if (!v) return "Selecione um assunto.";
      return "";
    }},
    mensagem: { el: form.mensagem, erro: form.querySelector('[data-erro="mensagem"]'), validar: function (v) {
      v = v.trim();
      if (v.length < 10) return "Mensagem muito curta (mín. 10 caracteres).";
      if (v.length > 1000) return "Máximo de 1000 caracteres.";
      return "";
    }},
  };

  function validarCampo(nome) {
    const c = campos[nome];
    const msg = c.validar(c.el.value);
    c.erro.textContent = msg;
    c.el.style.borderColor = msg ? "var(--color-error)" : "";
    return !msg;
  }

  Object.keys(campos).forEach(function (nome) {
    campos[nome].el.addEventListener("input", function () { validarCampo(nome); });
    campos[nome].el.addEventListener("blur", function () { validarCampo(nome); });
  });

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    let ok = true;
    Object.keys(campos).forEach(function (nome) {
      if (!validarCampo(nome)) ok = false;
    });
    if (!ok) return;

    const modal = document.getElementById("modalSucesso");
    if (modal) modal.classList.add("estaAberto");
    form.reset();
  });
})();
