/* Ícones SVG inline — tema espacial */
(function () {
  "use strict";

  const SVG_ATTR =
    'xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"';

  const ICONS = {
    satellite: '<rect x="9" y="9" width="6" height="6" transform="rotate(45 12 12)"/><path d="M5 5l3 3"/><path d="M16 16l3 3"/><path d="M8 16l-3 3"/><path d="M16 8l3-3"/><circle cx="12" cy="12" r="1.2" fill="currentColor"/>',
    planet: '<circle cx="12" cy="12" r="6"/><ellipse cx="12" cy="12" rx="10" ry="3" transform="rotate(-25 12 12)"/>',
    radar: '<circle cx="12" cy="12" r="9"/><path d="M12 12L20 8"/><circle cx="12" cy="12" r="1.2" fill="currentColor"/><path d="M12 3a9 9 0 019 9"/>',
    alert: '<path d="M12 3L2 20h20L12 3z"/><line x1="12" y1="10" x2="12" y2="14"/><circle cx="12" cy="17" r="0.7" fill="currentColor"/>',
    region: '<path d="M12 22s-7-7-7-13a7 7 0 0114 0c0 6-7 13-7 13z"/><circle cx="12" cy="9" r="2.5"/>',
    waves: '<path d="M2 8c2-2 4-2 6 0s4 2 6 0 4-2 6 0"/><path d="M2 14c2-2 4-2 6 0s4 2 6 0 4-2 6 0"/><path d="M2 20c2-2 4-2 6 0s4 2 6 0 4-2 6 0"/>',
    fire: '<path d="M12 22c-4 0-7-3-7-6 0-3 2-5 3-6 0 2 1 3 2 3 0-4 1-7 4-10 0 4 5 6 5 11 0 5-3 8-7 8z"/>',
    quake: '<path d="M2 12h2l2-6 3 12 3-8 3 5 2-3h5"/>',
    cloud: '<path d="M7 18a5 5 0 010-10 6 6 0 0111-2 4 4 0 011 8H7z"/>',
    chart: '<path d="M4 20V8"/><path d="M10 20V4"/><path d="M16 20v-9"/><path d="M22 20H2"/>',
    shield: '<path d="M12 3l8 3v6c0 5-4 8-8 9-4-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
    radio: '<circle cx="12" cy="12" r="2"/><path d="M5 5a10 10 0 0114 0"/><path d="M8 8a6 6 0 018 0"/><path d="M5 19a10 10 0 0114 0"/><path d="M8 16a6 6 0 018 0"/>',
    bolt: '<path d="M13 2L4 14h7l-1 8 9-12h-7l1-8z"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5" fill="currentColor"/>',
    check: '<path d="M5 12l5 5 9-11"/>',
    sparkle: '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/>',
    mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
    pin: '<path d="M12 22s-7-7-7-13a7 7 0 0114 0c0 6-7 13-7 13z"/><circle cx="12" cy="9" r="2.5"/>',
    phone: '<path d="M5 4h4l2 5-3 2a11 11 0 005 5l2-3 5 2v4a2 2 0 01-2 2A16 16 0 013 6a2 2 0 012-2z"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-7 8-7s8 3 8 7"/>',
    rocket: '<path d="M12 2c4 4 6 8 6 12l-2 2-4-2-4 2-2-2c0-4 2-8 6-12z"/><circle cx="12" cy="10" r="1.5"/><path d="M9 18l-2 3M15 18l2 3"/>',
    github: '<path fill="currentColor" stroke="none" d="M12 2C6.48 2 2 6.58 2 12.25c0 4.54 2.87 8.38 6.84 9.74.5.1.68-.22.68-.49v-1.7c-2.78.62-3.37-1.36-3.37-1.36-.46-1.19-1.12-1.5-1.12-1.5-.91-.64.07-.62.07-.62 1.01.07 1.54 1.06 1.54 1.06.9 1.57 2.36 1.12 2.94.85.09-.67.35-1.12.64-1.38-2.22-.26-4.56-1.14-4.56-5.06 0-1.12.39-2.03 1.03-2.74-.1-.26-.45-1.3.1-2.72 0 0 .84-.28 2.75 1.05A9.4 9.4 0 0112 6.84c.85 0 1.71.12 2.5.34 1.91-1.33 2.75-1.05 2.75-1.05.55 1.42.2 2.46.1 2.72.64.71 1.03 1.62 1.03 2.74 0 3.93-2.34 4.79-4.57 5.05.36.32.68.94.68 1.9v2.81c0 .27.18.6.69.49A10.04 10.04 0 0022 12.25C22 6.58 17.52 2 12 2z"/>',
    linkedin: '<path fill="currentColor" stroke="none" d="M4.98 3.5C4.98 4.88 3.87 6 2.5 6S0 4.88 0 3.5 1.12 1 2.5 1s2.48 1.12 2.48 2.5zM.22 8h4.56v14H.22V8zm7.5 0h4.37v1.92h.06c.61-1.15 2.1-2.36 4.32-2.36 4.62 0 5.47 3.04 5.47 7v7.44h-4.56v-6.6c0-1.57-.03-3.6-2.19-3.6-2.19 0-2.52 1.71-2.52 3.48V22H7.72V8z"/>',
  };

  function svgFor(name) {
    const body = ICONS[name];
    if (!body) return "";
    return '<svg ' + SVG_ATTR + ' class="icone">' + body + '</svg>';
  }

  function inject() {
    document.querySelectorAll("[data-icon]").forEach(function (el) {
      const name = el.getAttribute("data-icon");
      const svg = svgFor(name);
      if (svg) el.innerHTML = svg;
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", inject);
  } else {
    inject();
  }

  window.OrbitaIcons = { svgFor, inject };
})();
